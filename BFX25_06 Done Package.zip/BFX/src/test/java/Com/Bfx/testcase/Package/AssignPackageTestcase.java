package Com.Bfx.testcase.Package;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Com.Bfx.BaseClass.Baseclass;
import Com.Bfx.BaseClass.ExtentTestNGITestListener;
import Com.Bfx.POM.patient.BfxPatient;
import Com.Bfx.Package.BfxAddPackage;
import Com.Bfx.Package.BfxAssignPackage;


@Listeners(ExtentTestNGITestListener.class)

public class AssignPackageTestcase extends Baseclass {

	BfxPatient Patients;
	BfxAddPackage AddPackage;
	BfxAssignPackage AssignPackage;

	/*
	 * @Test(description = "verify and Click on Assign Package button  ") public
	 * void clickonAssignPackagebutton() throws Exception { AssignPackage = new
	 * BfxAssignPackage(); AssignPackage.clickOnAssignPackage(); }
	 * 
	 * @Test(description = "Assign package to Specific patient") public void
	 * assignPackageToSpecificPatients() throws Exception { AssignPackage = new
	 * BfxAssignPackage(); AssignPackage.clickOnAssignPackage();
	 * AssignPackage.assignPackagetoSpecificPatient(); }
	 * 
	 * @Test(description = "Assign the same pacakge to the same patient") public
	 * void assignedtheSamePackageToSamePatients() throws Exception { AssignPackage
	 * = new BfxAssignPackage(); AssignPackage.clickOnAssignPackage();
	 * AssignPackage.assignedTheSamePackageToSamePatient(); }
	 */

	/*
	 * @Test(description = "Verify the Assign package in the profile section")
	 * public void verifytheAssignPackageintheProfileSection() throws Exception {
	 * AssignPackage = new BfxAssignPackage(); AssignPackage.clickOnAssignPackage();
	 * AssignPackage.verifyTheAssignPackageInTheProfileSection(); }
	 */

	/*
	 * @Test(description = "User navigate to Add Receipt page ") public void
	 * verifytheUserNavigatetoAddReceiptpage() throws Exception { AssignPackage =
	 * new BfxAssignPackage(); AssignPackage.clickOnAssignPackage();
	 * AssignPackage.verifyAddReceiptPage(); }
	 */

	/*
	 * @Test(description = "Verify Error Message without submitting input") public
	 * void verifyAssignPackageErrorMessages() throws Exception { AssignPackage =
	 * new BfxAssignPackage(); AssignPackage.clickOnAssignPackage();
	 * AssignPackage.verifyAssignPackageErrorMessage(); }
	 */

	/*
	 * @Test(description = "Verify Already assign patient Assign to same package")
	 * public void verifyAlreadyassignpatientAssignToSamepackage() throws Exception
	 * { AssignPackage = new BfxAssignPackage();
	 * AssignPackage.clickOnAssignPackage();
	 * AssignPackage.verifyAlreadyassignpatientAssigntosamepackage(); }
	 */

	//////////////////////// Search ////////////////////////////

	/*
	 * @Test(description = " Verify the Patient name by their search filter") public
	 * void searchAssignPatientName() throws Exception { AssignPackage = new
	 * BfxAssignPackage(); AssignPackage.clickOnAssignPackageSearchBtn();
	 * AssignPackage.searchAssignPatientName(); }
	 * 
	 * @Test(description = "Verify the Assign Package name by their search filter")
	 * public void searchAssignPackageName() throws Exception { AssignPackage = new
	 * BfxAssignPackage(); AssignPackage.clickOnAssignPackageSearchBtn();
	 * AssignPackage.searchAssignPackageName(); }
	 * 
	 * @Test(description = " Verify the Package Number by their search filter")
	 * public void searchAssignPackageNumbers() throws Exception { AssignPackage =
	 * new BfxAssignPackage(); AssignPackage.clickOnAssignPackageSearchBtn();
	 * AssignPackage.searchAssignPackageNumber(); }
	 * 
	 * @Test(description = "Verify the Receipt Number by their search filter")
	 * public void searchAssignReceiptNumber() throws Exception { AssignPackage =
	 * new BfxAssignPackage(); AssignPackage.clickOnAssignPackageSearchBtn();
	 * AssignPackage.searchAssignReceiptNumber(); }
	 * 
	 * @Test(description = "Verify the Total Price by their search filter") public
	 * void searchAssignTotalPrice() throws Exception { AssignPackage = new
	 * BfxAssignPackage(); AssignPackage.clickOnAssignPackageSearchBtn();
	 * AssignPackage.searchAssignTotalPrice(); }
	 * 
	 * @Test(description = "Verify the Discount Price by their search filter")
	 * public void searchAssignDiscountPrice() throws Exception { AssignPackage =
	 * new BfxAssignPackage(); AssignPackage.clickOnAssignPackageSearchBtn();
	 * AssignPackage.searchAssignDiscountPrice(); }
	 * 
	 * @Test(description = "Verify the Status by their search filter") public void
	 * searchAssignStatus() throws Exception { AssignPackage = new
	 * BfxAssignPackage(); AssignPackage.clickOnAssignPackageSearchBtn();
	 * AssignPackage.searchAssignStatus(); }
	 */

	@Test(description = " Verify the Package Expire Date by their search filter")
	public void searchAssignExpireDate() throws Exception {
		AssignPackage = new BfxAssignPackage();
		AssignPackage.clickOnAssignPackageSearchBtn();
		AssignPackage.searchAssignExpireDate();
	}

}
