package Com.Bfx.Package;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.annotations.Test;

import Com.Bfx.BaseClass.BasePage;
import Com.Bfx.POM.patient.BfxAddPatient;
import Com.Bfx.Utilities.BfxUtlilities;

public class BfxAssignPackage extends BasePage {

	BfxAddPackage AddPackage = new BfxAddPackage();

	BasePage baseobj = new BasePage();
	JavascriptExecutor js = (JavascriptExecutor) baseobj.driver;

	public WebDriver driver;

	public BfxAssignPackage() {
		this.driver = baseobj.driver;
	}

	final String AssignPackages = "//a[@href='/staging-pms/packages']//div[@role='button']";
	final String Utilities = "/html/body/div[1]/div[1]/div/div[1]/div/div/div/div/ul[5]/li/div";
	final String AssignPackageAddBtn = "//body[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[4]/button[1]";
	final String PatientName = "//input[@id='patient']";
	final String PackageName = "//input[@id='package']";
	final String Description = "//input[@id='description']";
	final String AssignPackagebtn = "//button[@id='assignPackage']";
	final String PackageAssignedErrorMsg = "//div[contains(text(),'Package already assigned to the patient')]";
	final String PatientSearchBar = "/html/body/div/div[1]/div/header/div/div[2]/div[1]/div/form/div[2]/div/div/div/input";
	final String SelectPackageFromProfile = "/html/body/div/div[1]/div/div[2]/div[1]/div/div/div[1]/div[2]/div/div[2]/div/div[3]/div/button[6]";
	final String VerifyPackageName = "/html/body/div/div[1]/div/div[2]/div[1]/div/div/div[1]/div[2]/div/div[6]/div/div/div[2]/div[2]/div/table/tbody/tr/td[2]";
	final String VerifyAddReceiptPage = "//h2[normalize-space()='Add Receipt']";
	final String PackageAlreadyAssigned = "//div[contains(@class,'Toastify')]";
	final String Searchbtn = "/html/body/div/div[1]/div/div[2]/div[1]/div/div[1]/div[2]/div[3]/button";
	final String SearchSelect = "//div[contains(text(),'Patient Name')]";
	
	final String SearchPatientName="//body//tbody//tr[1]//td[1]";
	final String SearchPackageName="//body//tbody//tr[1]//td[2]";
	final String SearchPackageNumber="//body//tbody//tr[1]//td[3]";
	final String SearchReceiptNumber="//body//tbody//tr[1]//td[5]";
	final String SearchTotalPrice="//body//tbody//tr[1]//td[6]";
	final String SearchDiscountPrice="//body//tbody//tr[1]//td[7]";
	final String SearchStatus="//body//tbody//tr[1]//td[9]";
	final String SelectExpireDateBtn="/html/body/div[2]/div[3]/div/div[2]/div[3]/div/div/div/div/button";
    final String VerifyExpireDate="//body//tbody//tr[1]//td[8]";
	
    
    @FindBy(xpath = VerifyExpireDate)
	public WebElement verifyExpireDate;
	
	@FindBy(xpath = SearchPatientName)
	public WebElement searchPatientName;
	
	@FindBy(xpath = SearchPackageName)
	public WebElement searchPackageName;
	
	@FindBy(xpath = SearchPackageNumber)
	public WebElement searchPackageNumber;
	
	@FindBy(xpath = SearchReceiptNumber)
	public WebElement searchReceiptNumber;
	
	@FindBy(xpath = SearchTotalPrice)
	public WebElement searchTotalPrice;

	@FindBy(xpath = SearchDiscountPrice)
	public WebElement searchDiscountPrice;
	
	@FindBy(xpath = SearchStatus)
	public WebElement searchStatus;
	
	@FindBy(xpath = SelectExpireDateBtn)
	public WebElement selectExpireDateBtn;
	
	@FindBy(xpath = SearchSelect)
	public WebElement searchSelect;
	
	@FindBy(xpath = Searchbtn)
	public WebElement searchbtn;
	
	@FindBy(xpath = VerifyAddReceiptPage)
	public WebElement verifyAddReceiptPage;

	@FindBy(xpath = PackageAlreadyAssigned)
	public WebElement packageAlreadyAssigned;

	@FindBy(xpath = VerifyPackageName)
	public WebElement verifyPackageName;

	@FindBy(xpath = SelectPackageFromProfile)
	public WebElement selectPackageFromProfile;

	@FindBy(xpath = PackageAssignedErrorMsg)
	public WebElement packageAssignedErrorMsg;

	@FindBy(xpath = PatientSearchBar)
	public WebElement patientSearchBar;

	@FindBy(xpath = AssignPackages)
	public WebElement assignPackage;

	@FindBy(xpath = AssignPackageAddBtn)
	public WebElement assignPackageAddBtn;

	@FindBy(xpath = Utilities)
	public WebElement utilities;

	@FindBy(xpath = PatientName)
	public WebElement patientName;

	@FindBy(xpath = PackageName)
	public WebElement packageName;

	@FindBy(xpath = Description)
	public WebElement description;

	@FindBy(xpath = AssignPackagebtn)
	public WebElement assignPackagebtn;

	public void clickOnAssignPackage() throws Exception {
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(utilities);
		BfxUtlilities.clickOnElementByActionClass(assignPackage);
		Thread.sleep(5000);
		BfxUtlilities.clickOnElementByActionClass(assignPackageAddBtn);
		Thread.sleep(5000);
	}

	public void clickOnAssignPackageSearchBtn() throws Exception {
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(utilities);
		Thread.sleep(5000);
		BfxUtlilities.clickOnElementByActionClass(assignPackage);
		Thread.sleep(5000);
	}

	public void assignPackagetoSpecificPatient() throws Exception {
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(patientName);
		patientName.sendKeys(
				BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage", "PatientName"));
		BfxUtlilities.selectTheOption(1);
		Thread.sleep(3000);

		BfxUtlilities.clickOnElementByActionClass(packageName);
		packageName.sendKeys(
				BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage", "PackageName"));
		BfxUtlilities.selectTheOption(1);
		Thread.sleep(3000);

		BfxUtlilities.clickOnElementByActionClass(description);
		description.sendKeys(
				BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage", "Description"));
		BfxUtlilities.scrollByJavaExecutor();
		assignPackagebtn.click();
		Thread.sleep(5000);

	}

	public void assignedTheSamePackageToSamePatient() throws Exception {
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(patientName);
		patientName.sendKeys(
				BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage", "SamePatientName"));
		Thread.sleep(2000);
		BfxUtlilities.selectTheOption(1);

		BfxUtlilities.clickOnElementByActionClass(packageName);
		packageName.sendKeys(
				BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage", "SamePackageName"));
		Thread.sleep(2000);
		BfxUtlilities.selectTheOption(1);
		Thread.sleep(2000);
		BfxUtlilities.scrollByJavaExecutor();
		assignPackagebtn.click();
	}

	public void verifyTheAssignPackageInTheProfileSection() throws Exception {

		BfxUtlilities.clickOnElementByActionClass(patientName);
		patientName.sendKeys(
				BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage", "NewPatientName"));
		Thread.sleep(3000);
		BfxUtlilities.selectTheOption(1);

		BfxUtlilities.clickOnElementByActionClass(packageName);
		packageName.sendKeys(
				BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage", "NewPackageName"));
		Thread.sleep(5000);
		BfxUtlilities.selectTheOption(1);
		Thread.sleep(5000);

		BfxUtlilities.scrollByJavaExecutor();

		assignPackagebtn.click();
		Thread.sleep(5000);

		Thread.sleep(5000);
		BfxUtlilities.clickOnElementByActionClass(patientSearchBar);
		Thread.sleep(5000);
		patientSearchBar.sendKeys(
				BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage", "NewPatientName"));
		Thread.sleep(5000);
		BfxUtlilities.selectTheOption(1);
		Thread.sleep(4000);
		BfxUtlilities.clickOnElementByActionClass(selectPackageFromProfile);
		Thread.sleep(5000);
		BfxUtlilities.scrollByJavaExecutor();
		verifyPackageName.isDisplayed();
		String ActualError = verifyPackageName.getText();
		String ExpectedError = BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage",
				"NewPackageName");
		Assert.assertEquals(ExpectedError, ActualError);
		Thread.sleep(2000);
	}

	public void verifyAddReceiptPage() throws Exception {
		BfxUtlilities.clickOnElementByActionClass(patientName);
		patientName.sendKeys(
				BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage", "NewPatientName2"));
		Thread.sleep(3000);
		BfxUtlilities.selectTheOption(1);
		BfxUtlilities.clickOnElementByActionClass(packageName);
		packageName.sendKeys(
				BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage", "NewPackageName2"));
		Thread.sleep(5000);
		BfxUtlilities.selectTheOption(2);
		Thread.sleep(5000);
		BfxUtlilities.scrollByJavaExecutor();
		assignPackagebtn.click();
		Thread.sleep(5000);
		verifyAddReceiptPage.isDisplayed();
		String ActualError = verifyAddReceiptPage.getText();
		String ExpectedError = BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage",
				"VerifyAddReceiptPage");
		Assert.assertEquals(ExpectedError, ActualError);
		Thread.sleep(2000);
	}

	int counter = 0;

	public void verifyAssignPackageErrorMessage() throws Exception {
		assignPackagebtn.click();
		List<WebElement> allErrorMessage = driver.findElements(By.xpath("//p"));
		for (WebElement element : allErrorMessage) {
			String actualErrorText = element.getText();
			if (actualErrorText.equals(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage",
					"ErrorMessageForPatient"))) {
				counter = ++counter;
			} else if (actualErrorText.equals(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath,
					"AssignPackage", "ErrorMessageForPackage"))) {
				counter = ++counter;
			}
		}
		assertEquals(counter,
				BfxUtlilities.getIntegerDataFromJsonArray(PackagePgTestDataPath, "AssignPackage", "ErrorCount"));
	}

	public void verifyAlreadyassignpatientAssigntosamepackage() throws Exception {
		BfxUtlilities.clickOnElementByActionClass(patientName);
		patientName.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage",
				"AlreadyAssignPatient"));
		Thread.sleep(5000);
		BfxUtlilities.selectTheOption(1);
		BfxUtlilities.clickOnElementByActionClass(packageName);
		packageName.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage",
				"AlreadyAssignPackage"));
		Thread.sleep(7000);
		BfxUtlilities.selectTheOption(1);
		Thread.sleep(3000);
		BfxUtlilities.scrollByJavaExecutor();
		assignPackagebtn.click();
		Thread.sleep(5000);
		packageAlreadyAssigned.isDisplayed();
		String ActualError = packageAlreadyAssigned.getText();
		String ExpectedError = BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage",
				"AlreadyAssignPackageErrorMsg");
		Assert.assertEquals(ExpectedError, ActualError);
		Thread.sleep(2000);
	}

	
	/////////Search////
	
	public void searchAssignPatientName() throws Exception {
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(searchbtn);
		BfxUtlilities.clickOnElementByActionClass(AddPackage.searchInput);
		AddPackage.searchInput.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage", "SearchPatientName"));
		Thread.sleep(2000);	
		AddPackage.findButton.click();
		Thread.sleep(7000);
		searchPatientName.isDisplayed();
		String ActualError =searchPatientName.getText();
		String ExpectedError = BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage","SearchPatientName");
		Assert.assertEquals(ExpectedError, ActualError);
		Thread.sleep(2000);
	}

	
	public void searchAssignPackageName() throws Exception {
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(searchbtn);
		BfxUtlilities.clickOnElementByActionClass(searchSelect);
		BfxUtlilities.clickOnElementByActionClass(searchSelect);
		BfxUtlilities.selectTheOption(1);
		BfxUtlilities.clickOnElementByActionClass(AddPackage.searchInput);
		AddPackage.searchInput.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage", "SearchPackagename"));
		Thread.sleep(4000);	
		AddPackage.findButton.click();
		Thread.sleep(9500);
		searchPackageName.isDisplayed();
		Thread.sleep(4000);	
		String ActualError =searchPackageName.getText();
		String ExpectedError = BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage","SearchPackagename");
		Assert.assertEquals(ExpectedError, ActualError);
		Thread.sleep(2000);
	}
	
	public void searchAssignPackageNumber() throws Exception {
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(searchbtn);
		Thread.sleep(3000);	
		BfxUtlilities.clickOnElementByActionClass(searchSelect);
		BfxUtlilities.selectTheOption(2);
		BfxUtlilities.clickOnElementByActionClass(AddPackage.searchInput);
		AddPackage.searchInput.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage", "SearchPackageNumber"));
		Thread.sleep(2000);	
		AddPackage.findButton.click();
		Thread.sleep(7000);
		searchPackageNumber.isDisplayed();
		String ActualError =searchPackageNumber.getText();
		String ExpectedError = BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage","SearchPackageNumber");
		Assert.assertEquals(ExpectedError, ActualError);
		Thread.sleep(2000);
	}
	
	
	public void searchAssignReceiptNumber() throws Exception {
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(searchbtn);
		Thread.sleep(3000);	
		BfxUtlilities.clickOnElementByActionClass(searchSelect);
		BfxUtlilities.selectTheOption(3);
		BfxUtlilities.clickOnElementByActionClass(AddPackage.searchInput);
		AddPackage.searchInput.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage", "SearchReceiptNumber"));
		Thread.sleep(2000);	
		AddPackage.findButton.click();
		Thread.sleep(7000);
		searchReceiptNumber.isDisplayed();
		String ActualError =searchReceiptNumber.getText();
		String ExpectedError = BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage","SearchReceiptNumber");
		Assert.assertEquals(ExpectedError, ActualError);
		Thread.sleep(2000);
	}
	
	public void searchAssignTotalPrice() throws Exception {
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(searchbtn);
		Thread.sleep(3000);	
		BfxUtlilities.clickOnElementByActionClass(searchSelect);
		BfxUtlilities.selectTheOption(4);
		BfxUtlilities.clickOnElementByActionClass(AddPackage.searchInput);
		AddPackage.searchInput.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage", "SearchTotalPrice"));
		Thread.sleep(2000);	
		AddPackage.findButton.click();
		Thread.sleep(7000);
		searchTotalPrice.isDisplayed();
		String ActualError =searchTotalPrice.getText();
		String ExpectedError = BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage","SearchTotalPrice");
		Assert.assertEquals(ExpectedError, ActualError);
		Thread.sleep(2000);
	}
	
	public void searchAssignDiscountPrice() throws Exception {
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(searchbtn);
		Thread.sleep(3000);	
		BfxUtlilities.clickOnElementByActionClass(searchSelect);
		BfxUtlilities.selectTheOption(5);
		BfxUtlilities.clickOnElementByActionClass(AddPackage.searchInput);
		AddPackage.searchInput.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage", "SearchDiscountPrice"));
		Thread.sleep(2000);	
		AddPackage.findButton.click();
		Thread.sleep(7000);
		searchDiscountPrice.isDisplayed();
		String ActualError =searchDiscountPrice.getText();
		String ExpectedError = BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage","SearchDiscountPrice");
		Assert.assertEquals(ExpectedError, ActualError);
		Thread.sleep(2000);
	}
	
	public void searchAssignStatus() throws Exception {
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(searchbtn);
		Thread.sleep(3000);	
		BfxUtlilities.clickOnElementByActionClass(searchSelect);
		BfxUtlilities.selectTheOption(7);
		BfxUtlilities.clickOnElementByActionClass(AddPackage.searchInput);
		AddPackage.searchInput.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage", "SearchStatus"));
		Thread.sleep(2000);	
		AddPackage.findButton.click();
		Thread.sleep(7000);
		searchStatus.isDisplayed();
		String ActualError =searchStatus.getText();
		String ExpectedError = BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage","SearchStatus");
		Assert.assertEquals(ExpectedError, ActualError);
		Thread.sleep(2000);
	}
	
	
	public void searchAssignExpireDate() throws Exception {
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(searchbtn);
		Thread.sleep(3000);	
		BfxUtlilities.clickOnElementByActionClass(searchSelect);
		BfxUtlilities.selectTheOption(6);
		Thread.sleep(3000);	
		selectExpireDateBtn.click();
		Thread.sleep(3000);	
		selectExpireDateBtn.click();	
		calendar(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage", "CalendarIndex"),
				BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage", "BirthYear"),
				BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage", "BirthDay"));
		Thread.sleep(3000);
		AddPackage.findButton.click();
		Thread.sleep(7000);
		verifyExpireDate.isDisplayed();
		String ActualError =verifyExpireDate.getText();
		String ExpectedError = BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage","ExpectedExpireDate");
		Assert.assertEquals(ExpectedError, ActualError);
		Thread.sleep(2000);
		
		
	}
	
	
	
}
