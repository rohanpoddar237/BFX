package Com.Bfx.Package;

import org.junit.Assert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import Com.Bfx.BaseClass.BasePage;
import Com.Bfx.Utilities.BfxUtlilities;

public class BfxCancelAndVisitsPackage extends BasePage {
	
	BfxAddPackage AddPackage = new BfxAddPackage();
	BfxAssignPackage AssignPackage = new BfxAssignPackage();
	
	BasePage baseobj = new BasePage();
	JavascriptExecutor js = (JavascriptExecutor) baseobj.driver;

	public WebDriver driver;
	
	public BfxCancelAndVisitsPackage() {
		this.driver = baseobj.driver;
	} 
	
	//Change Tr[] for patient name
	final String PatientNameSelect = "//body//tbody//tr[2]//td[1]";
	final String VerifyCanceledStatus="//body//tbody//tr[1]//td[8]";
    final String PackageNumberSelect="/html/body/div/div[1]/div/div[2]/div[1]/div/div/div[1]/div[2]/div/div[6]/div/div/div[2]/div[2]/div/table/tbody/tr[3]/td[1]/button";
    final String PackageNumberSelect1="/html/body/div/div[1]/div/div[2]/div[1]/div/div/div[1]/div[2]/div/div[6]/div/div/div[2]/div[2]/div/table/tbody/tr[4]/td[1]/button";

	
	final String CancelButton="//button[normalize-space()='Cancel Package']";
	final String CancelPackagePopupYesBtn="//button[normalize-space()='Yes']";
	final String CancelStatus="//body//tbody//tr[1]//td[9]";
	final String PackageButton="/html/body/div/div[1]/div/div[2]/div[1]/div/div/div[1]/div[2]/div/div[2]/div/div[3]/div/button[6]";
	
    @FindBy(xpath = PatientNameSelect)
	public WebElement patientNameSelect;
	
    @FindBy(xpath = VerifyCanceledStatus)
	public WebElement verifyCanceledStatus;
	
    @FindBy(xpath = PackageNumberSelect)
	public WebElement packageNumberSelect;
    
    @FindBy(xpath = PackageNumberSelect1)
	public WebElement packageNumberSelect1;
	
    @FindBy(xpath = CancelButton)
	public WebElement cancelButton;
    
    @FindBy(xpath = PackageButton)
	public WebElement packageButton;
    
    @FindBy(xpath = CancelPackagePopupYesBtn)
  	public WebElement cancelPackagePopupYesBtn;
    
    @FindBy(xpath = CancelStatus)
   	public WebElement cancelStatus;
	
	public void clickOnAssignPackage() throws Exception {
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(AssignPackage.utilities);
		BfxUtlilities.clickOnElementByActionClass(AssignPackage.assignPackage);
		Thread.sleep(5000);
	}
	
	public void clickOnSearchPatientFilter()throws Exception  {
		BfxUtlilities.clickOnElementByActionClass(AssignPackage.searchbtn); 
		BfxUtlilities.clickOnElementByActionClass(AddPackage.searchInput);
		AddPackage.searchInput.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "CancelPackage", "SearchPatientName"));
		Thread.sleep(2000);	
		AddPackage.findButton.click();
		Thread.sleep(9000);
		Thread.sleep(5000);
	}
	
	public void cancelPackageFromAssignPackage()throws Exception	{
		//Change patientNameSelect xpath
		BfxUtlilities.clickOnElementByActionClass(patientNameSelect);
		Thread.sleep(10000);
		BfxUtlilities.clickOnElementByActionClass(cancelButton);
		BfxUtlilities.clickOnElementByActionClass(cancelPackagePopupYesBtn);
		Thread.sleep(8000);
		//Again Search for patient Cancel status
		BfxUtlilities.clickOnElementByActionClass(AssignPackage.searchbtn);
		BfxUtlilities.clickOnElementByActionClass(AddPackage.searchInput);
		AddPackage.searchInput.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "CancelPackage", "SearchPatientName"));
		Thread.sleep(2000);	
		AddPackage.findButton.click();
		Thread.sleep(9000);
		cancelStatus.isDisplayed();
		String ActualError =cancelStatus.getText();
		String ExpectedError = BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "CancelPackage","CancelStatus");
		Assert.assertEquals(ExpectedError, ActualError);
		Thread.sleep(5000);	
		patientNameSelect.isDisplayed();
		String ActualError1 =patientNameSelect.getText();
		String ExpectedError1 = BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "CancelPackage","SearchPatientName");
		Assert.assertEquals(ExpectedError1, ActualError1);
		Thread.sleep(2000);	
	}
	
	public void cancelPackageFromThePatientProfile()throws Exception
	{
		Thread.sleep(5000);
		BfxUtlilities.clickOnElementByActionClass(AssignPackage.patientSearchBar);
		Thread.sleep(5000);
		AssignPackage.patientSearchBar.sendKeys(
				BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "CancelPackage", "NewPatientName"));
		Thread.sleep(5000);
		BfxUtlilities.selectTheOption(2);
		Thread.sleep(8000);
		Thread.sleep(4000);
		BfxUtlilities.clickOnElementByActionClass(packageButton);
		Thread.sleep(5000);
		BfxUtlilities.scrollByJavaExecutor();
		Thread.sleep(5000);
		packageNumberSelect.click();
		
	//	BfxUtlilities.clickOnElementByActionClass(packageNumberSelect);
		Thread.sleep(6000);
		BfxUtlilities.clickOnElementByActionClass(cancelButton);
		Thread.sleep(4000);
		BfxUtlilities.clickOnElementByActionClass(cancelPackagePopupYesBtn);
		Thread.sleep(6000);
        //Verify Cancel Status in profile //
		Thread.sleep(5000);
		BfxUtlilities.clickOnElementByActionClass(AssignPackage.patientSearchBar);
		Thread.sleep(5000);
		AssignPackage.patientSearchBar.sendKeys(
				BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "CancelPackage", "NewPatientName"));
		Thread.sleep(5000);
		BfxUtlilities.selectTheOption(2);
		Thread.sleep(8000);
		Thread.sleep(4000);
		BfxUtlilities.clickOnElementByActionClass(packageButton);
		Thread.sleep(5000);	
		BfxUtlilities.scrollByJavaExecutor();
		verifyCanceledStatus.isDisplayed();
		String ActualError =verifyCanceledStatus.getText();
		String ExpectedError = BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "CancelPackage","CancelStatus");
		Assert.assertEquals(ExpectedError, ActualError);
		Thread.sleep(2000);			
	}
	
	
	public void verifyCanceledStatusInAssignedPackageWhenCanceledFromTheProfile() throws Exception
	{
		Thread.sleep(5000);
		BfxUtlilities.clickOnElementByActionClass(AssignPackage.patientSearchBar);
		Thread.sleep(5000);
		AssignPackage.patientSearchBar.sendKeys(
				BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "CancelPackage", "NewPatientName"));
		Thread.sleep(5000);
		BfxUtlilities.selectTheOption(2);
		Thread.sleep(8000);
		Thread.sleep(4000);
		BfxUtlilities.clickOnElementByActionClass(packageButton);
		Thread.sleep(5000);
		BfxUtlilities.scrollByJavaExecutor();
		Thread.sleep(5000);
		packageNumberSelect1.click();
		
	//	BfxUtlilities.clickOnElementByActionClass(packageNumberSelect);
		Thread.sleep(6000);
		BfxUtlilities.clickOnElementByActionClass(cancelButton);
		Thread.sleep(4000);
		BfxUtlilities.clickOnElementByActionClass(cancelPackagePopupYesBtn);
		Thread.sleep(6000);
		
        //Verify Cancel Status in Assigned Package //
		
		BfxUtlilities.clickOnElementByActionClass(AssignPackage.searchbtn);
		BfxUtlilities.clickOnElementByActionClass(AddPackage.searchInput);
		AddPackage.searchInput.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "CancelPackage", "NewPatientName"));
		Thread.sleep(2000);	
		AddPackage.findButton.click();
		Thread.sleep(9000);
		BfxUtlilities.scrollByJavaExecutor();
		verifyCanceledStatus.isDisplayed();
		String ActualError =verifyCanceledStatus.getText();
		String ExpectedError = BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "CancelPackage","CancelStatus");
		Assert.assertEquals(ExpectedError, ActualError);
		Thread.sleep(2000);			
	}
	
	
	
	
	
	
	
	
	

}
