package Com.Bfx.POM.patient;

import static org.junit.Assert.assertEquals;

import java.util.Calendar;
import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.annotations.Test;
import Com.Bfx.BaseClass.BasePage;
import Com.Bfx.Utilities.Bfx_Utlilities;
import net.bytebuddy.utility.RandomString;

public class Bfx_POM_Add_Patient extends BasePage {

	final String AddPatientbtn = "/html/body/div/div[1]/div/div[2]/div[1]/div/div/div/div[3]/div[1]/div[2]/div[4]/button";
	final String ReferralSourceDropdown = "//input[@id='cmbReferralSource']";
	final String FirstNameTextBox = "//input[@id=\"txtFirstName\"]";
	final String LastNameTextBox = "//input[@id=\"txtLastName\"]";
	final String GenderRadioButton = "//input[@id='rdbMale']";
	final String DateOfBirth = "//input[@id='dob']";
	final String EmailTextBox = "//input[@id=\"txtEmail\"]";
	final String PrimaryPhoneTypeRadioButton = "//input[@id='rdbWork']";
	final String PrimaryPhoneNumberTextBox = "//input[@name=\"PrimaryPhone\"]";
	final String LocationDropdown = "//input[@id='cmbClinicLocation']";
	final String SavePatientButton = "//*[@id=\"savepatient\"]";
	final String CancelButton="(//button[@name=\"btnDoneSteps\"])[1]";
	final String PatientAddedPopupMessageWithBasicInfo="//p[text()=\"Patient record has been created!\"]";
	final String DoneForNowButton="//button[text()=\"Done for Now\"]";
	final String SaveAndGoToNextButton="//button[text()=\"Save & Go To Next\"]";
	final String GoToNextButton="//button[@name=\"btnDoneSteps\"]";
	final String DuplicatePatientRecordPopup="//div[text()=' Duplicate Record(s) found']";
	final String PotentialDuplicatePatientRecordPopup="//div[text()='Potential Duplicate Record(s) found']";
	final String PotentialSaveButton="//button[text()='Save']";

	
	JavascriptExecutor js = (JavascriptExecutor) driver;

	@FindBy(xpath = AddPatientbtn)
	WebElement addPatient;

	@FindBy(xpath = ReferralSourceDropdown)
	WebElement ReferralSource;

	@FindBy(xpath = FirstNameTextBox)
	public WebElement firstNameTextBox;

	@FindBy(xpath = LastNameTextBox)
	public WebElement lastNameTextBox;

	@FindBy(xpath = GenderRadioButton)
	public WebElement genderRadioButton;

	@FindBy(xpath = EmailTextBox)
	public WebElement emailTextBox;

	@FindBy(xpath = PrimaryPhoneTypeRadioButton)
	public WebElement primaryPhoneTypeRadioButton;

	@FindBy(xpath = PrimaryPhoneNumberTextBox)
	public WebElement primaryPhoneNumberTextBox;

	@FindBy(xpath = LocationDropdown)
	public WebElement locationDropdown;

	@FindBy(xpath = DateOfBirth)
	public WebElement dateOfBirth;

	@FindBy(xpath = SavePatientButton)
	public WebElement savePatientButton;
	
	@FindBy(xpath=CancelButton)
	public WebElement cancelButton;
	
	@FindBy(xpath=PatientAddedPopupMessageWithBasicInfo)
	WebElement patientAddedPopupMessageWithBasicInfo;
	
	@FindBy(xpath=DoneForNowButton)
	WebElement doneForNowButton;
	
	@FindBy(xpath=SaveAndGoToNextButton)
	public WebElement saveAndGoToNextButton;
	
	@FindBy(xpath=GoToNextButton)
	public WebElement goToNextButton;
	
	
	@FindBy(xpath=DuplicatePatientRecordPopup)
	WebElement duplicatePatientRecordPopup;
	
	@FindBy(xpath=PotentialDuplicatePatientRecordPopup)
	WebElement potentialDuplicatePatientRecordPopup;
	
	@FindBy(xpath=PotentialSaveButton)
	WebElement potentialSaveButton;
	
	//Driver for Add Patient
	static WebDriver driver;
	public Bfx_POM_Add_Patient(WebDriver driver) {
		super(driver);
		this.driver = driver; 
	}
	
    //Click on Add patient button
	public void ClickOnAddPatient() throws Exception {
		addPatient.click();
	}
	//click on cancel button
	public void clickOnCancelButton() throws InterruptedException {
		Bfx_Utlilities.clickOnElementByJavaExecutor(cancelButton);
	}
	//click on save button
	public void clickSavePatientButton() throws InterruptedException {
		Bfx_Utlilities.scrollByJavaExecutor();
		Thread.sleep(1000);
		Bfx_Utlilities.clickOnElementByJavaExecutor(savePatientButton);
	}

	//Validate All basic Information
	public void BasicInformation() throws Exception {
		Thread.sleep(5000);
		Bfx_Utlilities.clickOnElementByActionClass(ReferralSource);
		Bfx_Utlilities.selectTheOption(2);
		firstNameTextBox.sendKeys(Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath, "AddNewPatient", "PatientsFirstName"));
		lastNameTextBox.sendKeys(Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath, "AddNewPatient", "PatientsLastName"));
		Bfx_Utlilities.clickOnElementByActionClass(genderRadioButton);
		Thread.sleep(2000);
		 dateOfBirth.click();
		calendar(Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath, "AddNewPatient", "CalendarIndex"),
				Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath, "AddNewPatient", "BirthYear"),
				Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath, "AddNewPatient", "BirthDay"));
		Thread.sleep(1000);
		Bfx_Utlilities.clickOnElementByActionClass(primaryPhoneTypeRadioButton);
		Thread.sleep(2000);
		primaryPhoneNumberTextBox.sendKeys(Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath,"AddNewPatient", "PrimaryPhoneNumber1"));
		emailTextBox.sendKeys(Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath, "AddNewPatient", "PatientEmail"));
		Bfx_Utlilities.clickOnElementByActionClass(locationDropdown);
		Bfx_Utlilities.selectTheOption(1);
		JavascriptExecutor jsx = (JavascriptExecutor) driver;
		jsx.executeScript("window.scrollBy(0,400)", "");
		Bfx_Utlilities.clickOnElementByActionClass(savePatientButton);
		Thread.sleep(3000);
		Bfx_Utlilities.clickOnElementByActionClass(saveAndGoToNextButton);
	}

	//Assert Patient Successful Message
	public void verifyPatientAddedWithBasicInfo() throws Exception {
		Thread.sleep(4000);
		String actualPopupMessage = patientAddedPopupMessageWithBasicInfo.getText();
		String expectedPopupMessage = Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath, "AddNewPatient", "PatientAddedPopuMessage");
		Assert.assertEquals(expectedPopupMessage, actualPopupMessage);
		Thread.sleep(3000);
		Bfx_Utlilities.clickOnElementByActionClass(doneForNowButton);
		Thread.sleep(2000);
	}
	
	//Validate Duplicate Patient Details
	public void DuplicatePatientDetails() throws Exception {
		Thread.sleep(5000);
		Bfx_Utlilities.clickOnElementByActionClass(ReferralSource);
		Bfx_Utlilities.selectTheOption(2);
		firstNameTextBox.sendKeys(Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath, "AddNewPatient", "NewPatientsFirstName"));
		lastNameTextBox.sendKeys(Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath, "AddNewPatient", "NewPatientsLastName"));
		Bfx_Utlilities.clickOnElementByActionClass(genderRadioButton);
		Thread.sleep(2000);
		 dateOfBirth.click();
		calendar(Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath, "AddNewPatient", "CalendarIndex"),
				Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath, "AddNewPatient", "BirthYear"),
				Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath, "AddNewPatient", "BirthDay"));
		Thread.sleep(1000);
		Bfx_Utlilities.clickOnElementByActionClass(primaryPhoneTypeRadioButton);
		Thread.sleep(2000);
		primaryPhoneNumberTextBox.sendKeys(Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath,"AddNewPatient", "PrimaryPhoneNumber1"));
		emailTextBox.sendKeys(Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath, "AddNewPatient", "PatientEmail"));
		Bfx_Utlilities.clickOnElementByActionClass(locationDropdown);
		Bfx_Utlilities.selectTheOption(1);
		JavascriptExecutor jsx = (JavascriptExecutor) driver;
		jsx.executeScript("window.scrollBy(0,400)", "");
		Bfx_Utlilities.clickOnElementByActionClass(savePatientButton);
		Thread.sleep(3000);
		//Bfx_Utlilities.clickOnElementByActionClass(saveAndGoToNextButton);
	}

	//Assert Duplicate Patient Details
	public void verifyDuplicatePatientRecords() throws Exception {
		String actualText = duplicatePatientRecordPopup.getText();
		String expectedText = Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath, "AddNewPatient", "DuplicatePatientRecordPopuMessage");
		Assert.assertEquals(expectedText, actualText);
	}
	
	
	
	
	//Validate Duplicate Patient Details
	public void PatientDuplicateEmailDetails() throws Exception {
		Thread.sleep(5000);
		Bfx_Utlilities.clickOnElementByActionClass(ReferralSource);
		Bfx_Utlilities.selectTheOption(2);
		firstNameTextBox.sendKeys(Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath, "AddNewPatient", "NewPatientsFirstName"));
		lastNameTextBox.sendKeys(Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath, "AddNewPatient", "NewPatientsLastName"));
		Bfx_Utlilities.clickOnElementByActionClass(genderRadioButton);
		Thread.sleep(2000);
		 dateOfBirth.click();
		calendar(Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath, "AddNewPatient", "CalendarIndex"),
				Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath, "AddNewPatient", "BirthYear"),
				Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath, "AddNewPatient", "BirthDay"));
		Thread.sleep(1000);
		Bfx_Utlilities.clickOnElementByActionClass(primaryPhoneTypeRadioButton);
		Thread.sleep(2000);
		primaryPhoneNumberTextBox.sendKeys(Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath,"AddNewPatient", "PrimaryPhoneNumber1"));
		RandomString random=new RandomString();
		String randomEmail=random.make(2);
		String email=randomEmail+Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath, "AddNewPatient", "PatientEmail");
		emailTextBox.sendKeys(email);
		//emailTextBox.sendKeys(Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath, "AddNewPatient", "PatientEmail"));
		Bfx_Utlilities.clickOnElementByActionClass(locationDropdown);
		Bfx_Utlilities.selectTheOption(1);
		JavascriptExecutor jsx = (JavascriptExecutor) driver;
		jsx.executeScript("window.scrollBy(0,400)", "");
		Bfx_Utlilities.clickOnElementByActionClass(savePatientButton);
		Thread.sleep(3000);
		//Bfx_Utlilities.clickOnElementByActionClass(saveAndGoToNextButton);
	}
	
	
	public void verifyPotentialDuplicatePatientRecord() throws Exception {
		String actualPopupMessage = potentialDuplicatePatientRecordPopup.getText();
		String expectedPopupMessage = Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath, "AddNewPatient", "PotentialDuplicatePatientRecordPopupMessage");
		assertEquals(actualPopupMessage, expectedPopupMessage);
		Thread.sleep(3000);
		Bfx_Utlilities.clickOnElementByActionClass(potentialSaveButton);
		Thread.sleep(3000);
	}
	
	
	//Assert all Error Messages
	int counter=0;
	public void verifyErrorMessage() throws Exception {
		
		List<WebElement> allErrorMessage = driver.findElements(By.xpath("//p"));
		for(WebElement element:allErrorMessage) {
			String actualErrorText = element.getText();
			if(actualErrorText.equals(Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath,"ErrorMessage", "ErrorMessageForReferralSourceDropdown"))) {
				counter=++counter;
			}
			else if(actualErrorText.equals(Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath,"ErrorMessage", "ErrorMessageForSalutation"))) {
				counter=++counter;
			}
			else if(actualErrorText.equals(Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath,"ErrorMessage", "ErrorMessageForFirstName"))) {
				counter=++counter ;
			}
			else if(actualErrorText.equals(Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath,"ErrorMessage", "ErrorMessageForLastName"))) {
				counter=++counter;
			}
			else if(actualErrorText.equals(Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath,"ErrorMessage", "ErrorMessageForGender"))) {
				counter=++counter;
			}
			else if(actualErrorText.equals(Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath,"ErrorMessage", "ErrorMessageForDateOfBirth"))) {
				counter=++counter;
			}
			else if(actualErrorText.equals(Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath,"ErrorMessage", "ErrorMessageForEmail"))) {
				counter=++counter;
			}
			else if(actualErrorText.equals(Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath,"ErrorMessage", "ErrorMessageForPrimaryPhoneType"))) {
				counter=++counter;
			}
			else if(actualErrorText.equals(Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath,"ErrorMessage", "ErrorMessageForPrimaryPhoneNumber"))) {
				counter=++counter;
			}
			else if(actualErrorText.equals(Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath,"ErrorMessage", "ErrorMessageForLocation"))) {
				counter=++counter;
			}
			else if(actualErrorText.equals(Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath,"ErrorMessage", "ErrorMessageForPhysician"))) {
				counter=++counter;
			}
			
			else if(actualErrorText.equals(Bfx_Utlilities.getStringDataFromJsonArray(PatientPgTestDataPath,"ErrorMessage", "ErrorMessageForProcedure"))) {
				counter=++counter;
			}
		}
		assertEquals(counter, Bfx_Utlilities.getIntegerDataFromJsonArray(PatientPgTestDataPath, "ErrorMessage", "ErrorCount"));
	}
	





}
