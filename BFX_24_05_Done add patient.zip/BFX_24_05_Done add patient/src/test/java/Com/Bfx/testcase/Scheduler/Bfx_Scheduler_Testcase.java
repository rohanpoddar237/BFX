package Com.Bfx.testcase.Scheduler;

import org.openqa.selenium.JavascriptExecutor;
import org.testng.annotations.Test;
import Com.Bfx.BaseClass.Baseclass;
import Com.Bfx.POM.Scheduler.Bfx_POM_Scheduler;

public class Bfx_Scheduler_Testcase extends Baseclass {

	Bfx_POM_Scheduler Schedulers;
	
	/*
	 * @Test(description = "verify patient page") public void VerifySchedulerpage()
	 * throws Exception { Schedulers= new Bfx_POM_Scheduler(driver);
	 * Schedulers.clickOnScheduler(); }
	 */
	
	@Test(description = "verify Scheduler time")
	public void VerifySchedulerbooktime() throws Exception {
		Schedulers= new Bfx_POM_Scheduler(driver);
		Schedulers.clickOnScheduler();
		
		Schedulers.clickOnSchedulerAppointment();
		Schedulers.clickOnSchedulerTIME();
		

	}
	


	
	
}
