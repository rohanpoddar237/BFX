package Com.Bfx.testcase.Login;

import org.testng.annotations.Test;
import Com.Bfx.BaseClass.Baseclass;
import Com.Bfx.POM.Login.LoginPage_POM;

public class LoginTestcase extends Baseclass {
	// Testcase Baseclass, created obj of the 'Loginpage' it can use everywhere in the class
	LoginPage_POM LoginPage;

	@Test(description = "User enters valid credentials")
	public void EnterCredentials() throws Exception {
		LoginPage = new LoginPage_POM(driver);
		LoginPage.EnterCredentials();
	}

	@Test(description = "User enters invalid credentials and clicks on Login button")
	public void EnterInvalidCredentials() throws Exception {
		LoginPage = new LoginPage_POM(driver);
		LoginPage.EnterInvalidCredentials();
	}

	@Test(description = "User does not enter any credentials and clicks on Login button")
	public void DoNotEnterCredentials() throws Exception {
		LoginPage = new LoginPage_POM(driver);
		LoginPage.DoNotEnterCredentials();
	}

	@Test(description = "Error message for invalid credentials should be displayed")
	public void VerifyErrorForInvalidCredentials() throws Exception {
		LoginPage = new LoginPage_POM(driver);
		LoginPage.VerifyErrorForInvalidCredentials();
	}

	@Test(description = "User does not enter any credentials and clicks on Login button")
	public void Validatepsw() throws Exception {
		LoginPage = new LoginPage_POM(driver);
		LoginPage.Validatepassword();
	}

	@Test(description = "Error message for Email and password should be displayed")
	public void VerifyErrorForMandatoryFields() throws Exception {
		LoginPage = new LoginPage_POM(driver);
		LoginPage.VerifyErrorForMandatoryFields();
	}

}
