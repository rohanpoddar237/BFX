package Com.Bfx.testcase.Package;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Com.Bfx.BaseClass.Baseclass;
import Com.Bfx.BaseClass.ExtentTestNGITestListener;
import Com.Bfx.POM.patient.BfxPatient;
import Com.Bfx.Package.BfxAddPackage;

@Listeners(ExtentTestNGITestListener.class)
public class AddPackageTestcase extends Baseclass {

	BfxPatient Patients;
	BfxAddPackage AddPackage;

	@Test(description = "Add Packages with procedure Details")
	public void addPackagewithProceduredetails() throws Exception {
		Patients = new BfxPatient();
		AddPackage = new BfxAddPackage();
		AddPackage.clickOnSetUpBtn();
		AddPackage.clickOnAddPackage();
		AddPackage.addPackageWithProcedureDetails();
	}

	@Test(description = "Add Packages with product Details")
	public void addPackagewithProductdetails() throws Exception {
		Patients = new BfxPatient();
		AddPackage = new BfxAddPackage();
		AddPackage.clickOnSetUpBtn();
		AddPackage.clickOnAddPackage();
		AddPackage.addPackageWithproductDetails();
	}

	@Test(description = "Add Packages with product and procedure Details")
	public void addPackagewithProcedureandproductDetails() throws Exception {
		Patients = new BfxPatient();
		AddPackage = new BfxAddPackage();
		AddPackage.clickOnSetUpBtn();
		AddPackage.clickOnAddPackage();
		AddPackage.addPackageWithProcedureandproductDetails();
	}

	@Test(description = "Add Packages with Patient Specific Name")
	public void addPackageWithPatientSpecificName() throws Exception {
		Patients = new BfxPatient();
		AddPackage = new BfxAddPackage();
		AddPackage.clickOnSetUpBtn();
		AddPackage.clickOnAddPackage();
		AddPackage.addPackageWithPatientSpecificDetails();
	}

	@Test(description = "Verify Error Message")
	public void addPackageWithErrormessage() throws Exception {
		Patients = new BfxPatient();
		AddPackage = new BfxAddPackage();
		AddPackage.clickOnSetUpBtn();
		AddPackage.clickOnAddPackage();
		AddPackage.verifySelectItemErrorMessage();
		AddPackage.verifyErrorMessage();
	}

	@Test(description = "Add Packages with product and procedure Details with multiple locations")
	public void addPackageWithProcedureandproductDetailswithMultipleLocations() throws Exception {
		Patients = new BfxPatient();
		AddPackage = new BfxAddPackage();
		AddPackage.clickOnSetUpBtn();
		AddPackage.clickOnAddPackage();
		AddPackage.addPackageWithProcedureandproductDetailswithMultipleLocation();
	}

	@Test(description = "Verify Number Error messages")
	public void verifyNumberErrorMsg() throws Exception {
		Patients = new BfxPatient();
		AddPackage = new BfxAddPackage();
		AddPackage.clickOnSetUpBtn();
		AddPackage.clickOnAddPackage();
		AddPackage.VerifytheNumbersErrorMsg();
		AddPackage.validateNumberErrorMsg();
	}

	@Test(description = "Verify Quantity Error messages")
	public void verifyQuantityErrorMsg() throws Exception {
		Patients = new BfxPatient();
		AddPackage = new BfxAddPackage();
		AddPackage.clickOnSetUpBtn();
		AddPackage.clickOnAddPackage();
		AddPackage.VerifytheQuantityErrorMsg();
		AddPackage.validateQuantityErrorMsg();
	}

	@Test(description = "Verify Duplicated Records Found")
	public void verifyDuplicatedRecordsFound() throws Exception {
		Patients = new BfxPatient();
		AddPackage = new BfxAddPackage();
		AddPackage.clickOnSetUpBtn();
		AddPackage.clickOnAddPackage();
		AddPackage.addPackageWithProcedureDetails();
		AddPackage.validateDuplicatedRecordsFound();
	}

	////// Search Testcases/////

	@Test(description = "Verify Package Page")
	public void verifyPackagePage() throws Exception {
		Patients = new BfxPatient();
		AddPackage = new BfxAddPackage();
		AddPackage.clickOnSetUpBtn();
		AddPackage.ValidatePackagePage();
	}

	@Test(description = " Verify the Package name by their search filter")
	public void searchPackageNameDetails() throws Exception {
		Patients = new BfxPatient();
		AddPackage = new BfxAddPackage();
		AddPackage.clickOnSetUpBtn();
		AddPackage.searchPackageName();
	}

	@Test(description = "Verify the Package Number by their search filter")
	public void searchPackagenumberDetails() throws Exception {
		Patients = new BfxPatient();
		AddPackage = new BfxAddPackage();
		AddPackage.clickOnSetUpBtn();
		AddPackage.searchPackageNumber();
	}

	@Test(description = "Verify the Package Deactivated by their search filter")
	public void searchPackageDeactivatedDetails() throws Exception {
		Patients = new BfxPatient();
		AddPackage = new BfxAddPackage();
		AddPackage.clickOnSetUpBtn();
		AddPackage.searchDeactivated();
	}

	@Test(description = "Verify the Package Total price by their search filter")
	public void searchPackageTotalPriceDetails() throws Exception {
		Patients = new BfxPatient();
		AddPackage = new BfxAddPackage();
		AddPackage.clickOnSetUpBtn();
		AddPackage.searchTotalPrice();
	}

	@Test(description = "Verify the Package Discounted price by their search filter")
	public void searchPackageDiscountedPriceDetails() throws Exception {
		Patients = new BfxPatient();
		AddPackage = new BfxAddPackage();
		AddPackage.clickOnSetUpBtn();
		AddPackage.searchDiscountedPrice();
	}

	@Test(description = "Verify the Package Status by their search filter")
	public void searchPackageStatusDetails() throws Exception {
		Patients = new BfxPatient();
		AddPackage = new BfxAddPackage();
		AddPackage.clickOnSetUpBtn();
		AddPackage.searchStatus();
	}

	@Test(description = "Download Package Data")
	public void downloadPackageData() throws Exception {
		Patients = new BfxPatient();
		AddPackage = new BfxAddPackage();
		AddPackage.clickOnSetUpBtn();
		AddPackage.downloadPackageData();
	}

}
