package Com.Bfx.testcase.Package;

import org.testng.annotations.Listeners;
import org.testng.annotations.Test;

import Com.Bfx.BaseClass.Baseclass;
import Com.Bfx.BaseClass.ExtentTestNGITestListener;
import Com.Bfx.POM.patient.BfxPatient;
import Com.Bfx.Package.BfxAddPackage;
import Com.Bfx.Package.BfxAssignPackage;
import Com.Bfx.Package.BfxCancelAndVisitsPackage;

@Listeners(ExtentTestNGITestListener.class)

public class CancelAndVisitsTestcase extends Baseclass {
	
	BfxPatient Patients;
	BfxAddPackage AddPackage;
	BfxAssignPackage AssignPackage;
	BfxCancelAndVisitsPackage CancelAndVisitPackage;
	
	
	/*
	 * @Test(description =
	 * "Cancel Package From Assign package page and Verify Canceled status in Assign package"
	 * ) public void cancelPackageFromAssignPackage() throws Exception {
	 * AssignPackage = new BfxAssignPackage(); CancelAndVisitPackage =new
	 * BfxCancelAndVisitsPackage(); CancelAndVisitPackage.clickOnAssignPackage();
	 * CancelAndVisitPackage.clickOnSearchPatientFilter();
	 * CancelAndVisitPackage.cancelPackageFromAssignPackage(); }
	 */
	
	/*
	 * @Test(description = "Cancel Package From the patient profile") public void
	 * cancelPackageFromThePatientsProfile() throws Exception { AssignPackage = new
	 * BfxAssignPackage(); CancelAndVisitPackage =new BfxCancelAndVisitsPackage();
	 * CancelAndVisitPackage.clickOnAssignPackage();
	 * CancelAndVisitPackage.cancelPackageFromThePatientProfile(); }
	 */
	
	
	
	
	public void verifyCanceledStatusInAssignedPackageWhenCanceledFromTheProfiles() throws Exception {
		AssignPackage = new BfxAssignPackage();
		CancelAndVisitPackage =new BfxCancelAndVisitsPackage();
		CancelAndVisitPackage.clickOnAssignPackage();
		CancelAndVisitPackage.verifyCanceledStatusInAssignedPackageWhenCanceledFromTheProfile();
	}
	
	
	
	

}
