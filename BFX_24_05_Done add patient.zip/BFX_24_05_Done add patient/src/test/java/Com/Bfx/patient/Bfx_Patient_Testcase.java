package Com.Bfx.patient;

import org.testng.annotations.Test;
import Com.Bfx.BaseClass.Baseclass;
import Com.Bfx.POM.patient.Bfx_POM_Patient;

public class Bfx_Patient_Testcase extends Baseclass {

	Bfx_POM_Patient Patients;

	@Test(description = "verify patient page")
	public void VerifyPatientPage() throws Exception {

		Patients = new Bfx_POM_Patient(driver);
		Patients.ClickOnpatients();

		Thread.sleep(2000);
		Patients.ClickOnpatients();
	}

	
	@Test(description = "Search for the patient by their name ")
	public void VerifyPatientname() throws Exception {
	
		Patients = new Bfx_POM_Patient(driver);
		Patients.ClickOnpatients();
		Thread.sleep(2000);
		Patients.ClickOnpatients();
		Patients.SearchPatientname();
	}

	@Test(description = "Search for the patient by their email")
	public void VerifyPatientemail() throws Exception { // common used object for every
		
		Patients = new Bfx_POM_Patient(driver);
		Patients.ClickOnpatients();
		Thread.sleep(2000);
		Patients.ClickOnpatients();
		Thread.sleep(2000);
		Patients.SearchPatientEmail();
	}

	@Test(description = "find the patient by their name")
	public void findrecords() throws Exception {

		Patients = new Bfx_POM_Patient(driver);
		Patients.ClickOnpatients();
		Thread.sleep(2000);
		Patients.ClickOnpatients();
		Thread.sleep(2000);
		Patients.SearchRecords();
	}

}





