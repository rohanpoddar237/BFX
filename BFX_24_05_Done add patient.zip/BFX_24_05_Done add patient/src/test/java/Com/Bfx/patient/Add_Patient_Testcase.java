package Com.Bfx.patient;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;
import Com.Bfx.BaseClass.Baseclass;
import Com.Bfx.POM.Login.LoginPage_POM;
import Com.Bfx.POM.patient.Bfx_POM_Add_Patient;
import Com.Bfx.POM.patient.Bfx_POM_Patient;

public class Add_Patient_Testcase extends Baseclass {

	Bfx_POM_Patient Patients;
	Bfx_POM_Add_Patient AddPatients;

	/*
	 * @Test(description = "verify Add Patient page") public void
	 * VerifyAddPatientpage() throws Exception { Patients = new
	 * Bfx_POM_Patient(driver); Patients.ClickOnpatients(); Thread.sleep(2000);
	 * Patients.ClickOnpatientsList(); // Add patient page AddPatients = new
	 * Bfx_POM_Add_Patient(driver); AddPatients.ClickOnAddPatient(); }
	 */

	/*
	 * @Test(description = "Add Patient Basic details") public void AddPatientInfo()
	 * throws Exception { Patients = new Bfx_POM_Patient(driver);
	 * Patients.ClickOnpatients(); Thread.sleep(2000);
	 * Patients.ClickOnpatientsList(); AddPatients = new
	 * Bfx_POM_Add_Patient(driver); AddPatients.ClickOnAddPatient();
	 * AddPatients.BasicInformation();
	 * AddPatients.verifyPatientAddedWithBasicInfo(); }
	 * 
	 * @Test(description = "Add Patient Error Message") public void
	 * verifyErrorMessage() throws Exception { Patients = new
	 * Bfx_POM_Patient(driver); Patients.ClickOnpatients(); Thread.sleep(2000);
	 * Patients.ClickOnpatientsList(); AddPatients = new
	 * Bfx_POM_Add_Patient(driver); AddPatients.ClickOnAddPatient();
	 * AddPatients.clickSavePatientButton(); AddPatients.verifyErrorMessage(); }
	 */
	
	/*
	 * @Test(description = "Verify Duplicate Patient Details") public void
	 * duplicatePatientDetails() throws Exception { Patients = new
	 * Bfx_POM_Patient(driver); Patients.ClickOnpatients(); Thread.sleep(2000);
	 * Patients.ClickOnpatientsList(); AddPatients = new
	 * Bfx_POM_Add_Patient(driver); Thread.sleep(3000);
	 * AddPatients.ClickOnAddPatient(); AddPatients.DuplicatePatientDetails();
	 * AddPatients.verifyDuplicatePatientRecords(); }
	 */
	
	@Test(description = "Verify Duplicate Patient Details")
	public void duplicatePatientEmail() throws Exception {
		Patients = new Bfx_POM_Patient(driver);
		Patients.ClickOnpatients();
		Thread.sleep(3000);
		Patients.ClickOnpatientsList();
		AddPatients = new Bfx_POM_Add_Patient(driver);
		Thread.sleep(3000);
		AddPatients.ClickOnAddPatient();
		AddPatients.PatientDuplicateEmailDetails();
		AddPatients.verifyPotentialDuplicatePatientRecord();
	}
	
	

}
