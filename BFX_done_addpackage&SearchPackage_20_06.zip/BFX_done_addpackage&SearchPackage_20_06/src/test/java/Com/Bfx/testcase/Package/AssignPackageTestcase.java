package Com.Bfx.testcase.Package;

import org.testng.annotations.Test;

import Com.Bfx.BaseClass.Baseclass;
import Com.Bfx.POM.patient.BfxPatient;
import Com.Bfx.Package.BfxAddPackage;
import Com.Bfx.Package.BfxAssignPackage;

public class AssignPackageTestcase extends Baseclass  {
	
	BfxPatient Patients;
	BfxAddPackage AddPackage;
	BfxAssignPackage AssignPackage;
	
	
	/*
	 * @Test(description = "verify and Click on Assign Package button  ") public void
	 * clickonAssignPackagebutton() throws Exception { AssignPackage = new
	 * BfxAssignPackage(); AssignPackage.clickOnAssignPackage(); }
	 * 
	 * 
	 * @Test(description = "Assign package to Specific patient") public void
	 * assignPackageToSpecificPatients() throws Exception { AssignPackage = new
	 * BfxAssignPackage(); AssignPackage.clickOnAssignPackage();
	 * AssignPackage.assignPackagetoSpecificPatient(); }
	 */
	 
	
	@Test(description = "Assign the same pacakge to the same patient")
	public void assignedtheSamePackageToSamePatients() throws Exception {
		AssignPackage = new BfxAssignPackage(); 
		AssignPackage.clickOnAssignPackage();		
		AssignPackage.assignedTheSamePackageToSamePatient();
	}
	
	
	

}
