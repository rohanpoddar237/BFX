package Com.Bfx.Package;

import static org.junit.Assert.assertEquals;

import java.util.List;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import Com.Bfx.BaseClass.BasePage;
import Com.Bfx.Utilities.BfxUtlilities;
import net.bytebuddy.utility.RandomString;

public class BfxAddPackage extends BasePage {
	BasePage baseobj = new BasePage();
	JavascriptExecutor js = (JavascriptExecutor) baseobj.driver;

	public WebDriver driver;

	public BfxAddPackage() {
		this.driver = baseobj.driver;
	}

	final String SetUpBtn = "//*[@id=\"root\"]/div[1]/div/div[1]/div/div/div/div/ul[12]/a/div";
	final String SetupSection = "/html/body/div/div[1]/div/div[2]/div[1]/div/div[2]/div/div/input";
	final String ClickonPackageBtn = "//div[1]//div[1]//div[4]//div[1]//div[2]//div[4]//button[1]";
	final String PatientSpecific = "//input[@name='patientSpecific']";
	final String PatientName = "//input[@id='patient']";

	final String PackageName = "//input[@id='packageName']";
	final String ExpireMonth = "//input[@id='expireAfterMonths']";
	final String PercentageRadiobtn = "//div[1]//div[3]//div[1]//div[2]//div[1]//div[1]//div[3]//fieldset[1]//div[1]//label[1]//span[1]//input[1]";
	final String PackageDiscount = "//body[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[3]/div[1]/div[2]/div[1]/div[1]/div[4]/div[1]/input[1]";
	final String Description = "//input[@id='description']";
	final String ProductBtn = "/html/body/div/div[1]/div/div[2]/div[1]/div[4]/div/div[2]/div/div/div[1]/fieldset/div/label[2]/span[1]/input";
	final String ProcedureBtn = "//*[@id=\"root\"]/div[1]/div/div[2]/div[1]/div[4]/div/div[2]/div/div/div[1]/fieldset/div/label[1]/span[1]/input";
	final String Location = "/html/body/div/div[1]/div/div[2]/div[1]/div[4]/div/div[2]/div/div/div[2]/div/div/div/input";
	final String ProductLocation = "//*[@id=\"locations\"]";
	final String ProcedureDropdown = "//input[@id='item']";
	final String ProductsDropdown = "//input[@id='item']";
	final String NumberOfVisits = "//input[@id='quantityOrVisits']";
	final String Quantity = "//input[@id='quantityOrVisits']";

	final String OriginalPrice = "//input[@id='originalPrice']";
	final String SelectItemProcedureBtn = "/html/body/div/div[1]/div/div[2]/div[1]/div[4]/div/div[2]/div/div/div[4]/fieldset/div/label[1]/span[1]/input";
	final String SelectItemDiscount = "/html/body/div/div[1]/div/div[2]/div[1]/div[4]/div/div[2]/div/div/div[5]/div/input";
	final String AddItemBtn = "//*[@id=\"root\"]/div[1]/div/div[2]/div[1]/div[4]/div/div[2]/div/button";
	final String SaveAndPublishBtn = "//*[@id=\"AssignPackage\"]";
	
	final String SearchSelect="//div[contains(text(),'Package Name')]";
	final String PackagePage="//h2[normalize-space()='Packages']";
	final String Searchbtn="/html/body/div/div[1]/div/div[2]/div[1]/div/div[4]/div[1]/div[2]/div[3]/button";
	final String SearchInput="/html/body/div[2]/div[3]/div/div[2]/div[3]/div/div/input";
	final String FindButton="/html/body/div[2]/div[3]/div/div[3]/button[1]";
	final String SearchPackageName="/html/body/div/div[1]/div/div[2]/div[1]/div/div[4]/div[2]/div/table/tbody/tr/td[1]";
	final String SearchPackageNumber="/html/body/div/div[1]/div/div[2]/div[1]/div/div[4]/div[2]/div/table/tbody/tr/td[2]";
	final String DeactivatedDropdown="/html/body/div[2]/div[3]/div/div[2]/div[3]/div/div/div";
	final String DeactivatedSearch="/html/body/div/div[1]/div/div[2]/div[1]/div/div[4]/div[2]/div/table/tbody/tr[1]/td[3]";
	final String TotalPrices="//td[normalize-space()='$1,722.60']";
	final String DiscountedPrice="//td[normalize-space()='$1,550.34']";
	final String Statustype="//tbody/tr[1]/td[6]";
	
	
	final String QuantityErrorMsg="//p[@id='quantityOrVisits-helper-text']";	
	final String DuplicatedRecords="//div[contains(text(),'Duplicate Package record found')]";	
	

	@FindBy(xpath = DiscountedPrice)
	public WebElement discountedPrice;
	
	@FindBy(xpath = Statustype)
	public WebElement statustype;
	
	@FindBy(xpath = TotalPrices)
	public WebElement totalPrice;
	
	@FindBy(xpath = DeactivatedDropdown)
	public WebElement deactivatedDropdown;

	@FindBy(xpath = DeactivatedSearch)
	public WebElement deactivatedSearch;
	
	@FindBy(xpath = SearchInput)
	public WebElement searchInput;
	
	@FindBy(xpath = SearchSelect)
	public WebElement searchSelect;
	
	@FindBy(xpath = SearchPackageNumber)
	public WebElement searchPackageNumber;
	
	
	@FindBy(xpath = PackagePage)
	public WebElement packagePage;
	
	@FindBy(xpath = DuplicatedRecords)
	public WebElement duplicatedRecords;
	
	@FindBy(xpath = QuantityErrorMsg)
	public WebElement quantityErrorMsg;
	
	
	@FindBy(xpath = SearchPackageName)
	public WebElement searchPackageName;
	
	@FindBy(xpath = FindButton)
	public WebElement findButton;

	@FindBy(xpath = SetUpBtn)
	public WebElement Setupbtn;

	@FindBy(xpath = SetupSection)
	public WebElement setUpSection;

	@FindBy(xpath = ClickonPackageBtn)
	public WebElement clickOnPackagebtn;

	@FindBy(xpath = PatientSpecific)
	public WebElement patientSpecific;

	@FindBy(xpath = PatientName)
	public WebElement patientName;

	@FindBy(xpath = PackageName)
	public WebElement packageName;

	@FindBy(xpath = ExpireMonth)
	public WebElement expiremonth;

	@FindBy(xpath = PercentageRadiobtn)
	public WebElement percentagebtn;

	@FindBy(xpath = PackageDiscount)
	public WebElement packageDiscount;

	@FindBy(xpath = Description)
	public WebElement description;

	@FindBy(xpath = ProcedureBtn)
	public WebElement procedureBtn;

	@FindBy(xpath = ProductBtn)
	public WebElement productBtn;

	@FindBy(xpath = Location)
	public WebElement location;

	@FindBy(xpath = ProductLocation)
	public WebElement productLocation;

	@FindBy(xpath = ProcedureDropdown)
	public WebElement procedureDropdown;

	@FindBy(xpath = ProductsDropdown)
	public WebElement productsDropdown;

	@FindBy(xpath = NumberOfVisits)
	public WebElement numberOfVisits;

	@FindBy(xpath = Quantity)
	public WebElement quantity;

	@FindBy(xpath = SelectItemProcedureBtn)
	public WebElement selectItemProcedureBtn;

	@FindBy(xpath = OriginalPrice)
	public WebElement originalPrice;

	@FindBy(xpath = AddItemBtn)
	public WebElement addItemBtn;

	@FindBy(xpath = SelectItemDiscount)
	public WebElement selectItemDiscount;

	@FindBy(xpath = SaveAndPublishBtn)
	public WebElement saveAndPublishBtn;
	
	@FindBy(xpath = Searchbtn)
	public WebElement searchbtn;
	

	public void clickOnSetUpBtn() throws Exception {
		Thread.sleep(3000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		String url = "https://bfxnonprod-cu.boomerangfxalpha.com/staging-pms/setup";
		driver.get(url);
		// js.executeScript("document.body.style.zoom = '80%';"); Thread.sleep(3000);
		// setUpSection.click();
		BfxUtlilities.clickOnElementByActionClass(setUpSection);
		BfxUtlilities.selectTheOption(14);
	}

	public void clickOnAddPackage() throws Exception {
		Thread.sleep(3000);
		clickOnPackagebtn.click();
	}

	public void addPackageWithProcedureDetails() throws Exception {
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(packageName);
		packageName.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "PackageName"));
		Thread.sleep(2000);
		BfxUtlilities.clickOnElementByActionClass(expiremonth);
		expiremonth.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "ExpireMonths"));
		percentagebtn.click();
		BfxUtlilities.clickOnElementByActionClass(packageDiscount);
		packageDiscount.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "PackageDiscount"));
		BfxUtlilities.scrollByJavaExecutor();
		BfxUtlilities.clickOnElementByActionClass(description);
		description.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "Description"));
		procedureBtn.click();
		BfxUtlilities.clickOnElementByActionClass(location);
		BfxUtlilities.selectTheOption(1);
		BfxUtlilities.clickOnElementByActionClass(procedureDropdown);
		BfxUtlilities.selectTheOption(3);
		BfxUtlilities.clickOnElementByActionClass(numberOfVisits);
		numberOfVisits.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "NumberOfVisits"));
		selectItemProcedureBtn.click();
		BfxUtlilities.clickOnElementByActionClass(selectItemDiscount);
		selectItemDiscount.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "Discount"));
		BfxUtlilities.scrollByJavaExecutor();
		BfxUtlilities.clickOnElementByActionClass(addItemBtn);
		BfxUtlilities.scrollByJavaExecutor();
		Thread.sleep(3000);

		BfxUtlilities.clickOnElementByActionClass(saveAndPublishBtn);
		Thread.sleep(3000);

	}

	public void addPackageWithproductDetails() throws Exception {

		Thread.sleep(3000);
		RandomString random=new RandomString();
		String randompackage=random.make(2);
		String pack=randompackage+BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "PackageName");
		packageName.sendKeys(pack);
		Thread.sleep(2000);
		BfxUtlilities.clickOnElementByActionClass(expiremonth);
		expiremonth.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "ExpireMonths"));
		percentagebtn.click();
		BfxUtlilities.clickOnElementByActionClass(packageDiscount);
		packageDiscount.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "PackageDiscount"));
		BfxUtlilities.scrollByJavaExecutor();
		BfxUtlilities.clickOnElementByActionClass(description);
		description.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "Description"));
		productBtn.click();
		BfxUtlilities.clickOnElementByActionClass(location);
		BfxUtlilities.selectTheOption(1);
		BfxUtlilities.clickOnElementByActionClass(productsDropdown);
		BfxUtlilities.selectTheOption(3);
		BfxUtlilities.clickOnElementByActionClass(quantity);
		quantity.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "Quantity"));
		BfxUtlilities.clickOnElementByActionClass(selectItemDiscount);
		selectItemDiscount.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "Discount"));
		BfxUtlilities.scrollByJavaExecutor();
		BfxUtlilities.clickOnElementByActionClass(addItemBtn);
		BfxUtlilities.scrollByJavaExecutor();
		Thread.sleep(3000);

		BfxUtlilities.clickOnElementByActionClass(saveAndPublishBtn);
		Thread.sleep(3000);

	}

	public void addPackageWithProcedureandproductDetails() throws Exception {
		// Procedure
		Thread.sleep(3000);
		RandomString random=new RandomString();
		String randompackage=random.make(2);
		String pack=randompackage+BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "PackageName");
		packageName.sendKeys(pack);
		Thread.sleep(2000);
		BfxUtlilities.clickOnElementByActionClass(expiremonth);
		expiremonth.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "ExpireMonths"));
		percentagebtn.click();
		BfxUtlilities.clickOnElementByActionClass(packageDiscount);
		packageDiscount.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "PackageDiscount"));
		BfxUtlilities.scrollByJavaExecutor();
		BfxUtlilities.clickOnElementByActionClass(description);
		description.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "Description"));
		procedureBtn.click();
		BfxUtlilities.clickOnElementByActionClass(location);
		BfxUtlilities.selectTheOption(1);
		BfxUtlilities.clickOnElementByActionClass(procedureDropdown);
		BfxUtlilities.selectTheOption(3);
		BfxUtlilities.clickOnElementByActionClass(quantity);
		numberOfVisits.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "NumberOfVisits"));
		selectItemProcedureBtn.click();
		BfxUtlilities.clickOnElementByActionClass(selectItemDiscount);
		selectItemDiscount.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "Discount"));
		BfxUtlilities.scrollByJavaExecutor();
		BfxUtlilities.clickOnElementByActionClass(addItemBtn);
		Thread.sleep(3000);
		BfxUtlilities.scrollUPByActionsClass();
		Thread.sleep(3000);
		// Product
		productBtn.click();
		BfxUtlilities.clickOnElementByActionClass(location);
		BfxUtlilities.selectTheOption(1);
		BfxUtlilities.clickOnElementByActionClass(productLocation);
		BfxUtlilities.selectTheOption(1);
		BfxUtlilities.clickOnElementByActionClass(procedureDropdown);
		BfxUtlilities.selectTheOption(4);
		BfxUtlilities.clickOnElementByActionClass(productsDropdown);
		BfxUtlilities.selectTheOption(4);
		BfxUtlilities.clickOnElementByActionClass(numberOfVisits);
		numberOfVisits.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "NumberOfVisits"));
		selectItemProcedureBtn.click();
		BfxUtlilities.clickOnElementByActionClass(selectItemDiscount);
		selectItemDiscount.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "Discount"));
		BfxUtlilities.scrollByJavaExecutor();
		BfxUtlilities.clickOnElementByActionClass(addItemBtn);
		BfxUtlilities.scrollByJavaExecutor();
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(saveAndPublishBtn);
		Thread.sleep(3000);
	}

	
	public void addPackageWithProcedureandproductDetailswithMultipleLocation() throws Exception {
		// Procedure
		Thread.sleep(3000);
		RandomString random=new RandomString();
		String randompackage=random.make(2);
		String pack=randompackage+BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "PackageName");
		packageName.sendKeys(pack);	
		
		Thread.sleep(2000);
		BfxUtlilities.clickOnElementByActionClass(expiremonth);
		expiremonth.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "ExpireMonths"));
		percentagebtn.click();
		BfxUtlilities.clickOnElementByActionClass(packageDiscount);
		packageDiscount.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "PackageDiscount"));
		BfxUtlilities.scrollByJavaExecutor();
		BfxUtlilities.clickOnElementByActionClass(description);
		description.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "Description"));
		procedureBtn.click();
		BfxUtlilities.clickOnElementByActionClass(location);
		BfxUtlilities.selectTheOption(2);
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(location);
		BfxUtlilities.selectTheOption(1);
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(procedureDropdown);
		BfxUtlilities.selectTheOption(3);	
		BfxUtlilities.clickOnElementByActionClass(quantity);
		numberOfVisits.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "NumberOfVisits"));
		selectItemProcedureBtn.click();
		BfxUtlilities.clickOnElementByActionClass(selectItemDiscount);
		selectItemDiscount.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "Discount"));
		BfxUtlilities.scrollByJavaExecutor();
		BfxUtlilities.clickOnElementByActionClass(addItemBtn);
		Thread.sleep(3000);
		BfxUtlilities.scrollUPByActionsClass();
		Thread.sleep(3000);
		// Product
		productBtn.click();
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(location);
		BfxUtlilities.selectTheOption(1);
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(location);
		BfxUtlilities.selectTheOption(2);
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(productLocation);
		BfxUtlilities.selectTheOption(1);
		BfxUtlilities.clickOnElementByActionClass(procedureDropdown);
		BfxUtlilities.selectTheOption(4);
		BfxUtlilities.clickOnElementByActionClass(productsDropdown);
		BfxUtlilities.selectTheOption(4);
		BfxUtlilities.clickOnElementByActionClass(numberOfVisits);
		numberOfVisits.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "NumberOfVisits"));
		selectItemProcedureBtn.click();
		BfxUtlilities.clickOnElementByActionClass(selectItemDiscount);
		selectItemDiscount.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "Discount"));
		BfxUtlilities.scrollByJavaExecutor();
		BfxUtlilities.clickOnElementByActionClass(addItemBtn);
		BfxUtlilities.scrollByJavaExecutor();
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(saveAndPublishBtn);
		Thread.sleep(3000);
	}
	
	
	
	
	public void addPackageWithPatientSpecificDetails() throws Exception {
		BfxUtlilities.clickOnElementByActionClass(patientSpecific);
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(patientName);
		patientName.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "PatientSpecificName"));
		BfxUtlilities.clickOnElementByActionClass(patientName);
		BfxUtlilities.selectTheOption(1);
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(packageName);
		packageName.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "PackageName"));
		Thread.sleep(2000);
		BfxUtlilities.clickOnElementByActionClass(expiremonth);
		expiremonth.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "ExpireMonths"));
		percentagebtn.click();
		BfxUtlilities.clickOnElementByActionClass(packageDiscount);
		packageDiscount.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "PackageDiscount"));
		BfxUtlilities.scrollByJavaExecutor();
		BfxUtlilities.clickOnElementByActionClass(description);
		description.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "Description"));
		productBtn.click();
		BfxUtlilities.clickOnElementByActionClass(location);
		BfxUtlilities.selectTheOption(1);
		BfxUtlilities.clickOnElementByActionClass(productsDropdown);
		BfxUtlilities.selectTheOption(3);
		BfxUtlilities.clickOnElementByActionClass(quantity);
		quantity.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "Quantity"));
		BfxUtlilities.clickOnElementByActionClass(selectItemDiscount);
		selectItemDiscount.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "Discount"));
		BfxUtlilities.scrollByJavaExecutor();
		BfxUtlilities.clickOnElementByActionClass(addItemBtn);
		BfxUtlilities.scrollByJavaExecutor();
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(saveAndPublishBtn);
		Thread.sleep(3000);

	}

	
	public void verifySelectItemErrorMessage()throws Exception	{
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(packageName);
		packageName.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "PackageName"));
		Thread.sleep(2000);
		BfxUtlilities.clickOnElementByActionClass(expiremonth);
		expiremonth.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "ExpireMonths"));
		percentagebtn.click();
		BfxUtlilities.clickOnElementByActionClass(packageDiscount);
		packageDiscount.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "PackageDiscount"));
		BfxUtlilities.scrollByJavaExecutor();
		BfxUtlilities.clickOnElementByActionClass(description);
		description.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "Description"));
		JavascriptExecutor jsx = (JavascriptExecutor) driver;
		jsx.executeScript("window.scrollBy(0,800)", "");
		BfxUtlilities.clickOnElementByActionClass(addItemBtn);
		}
	
	
	int counter=0;
	public void verifyErrorMessage() throws Exception {
		
		List<WebElement> allErrorMessage = driver.findElements(By.xpath("//p"));
		for(WebElement element:allErrorMessage) {
			String actualErrorText = element.getText();
			if(actualErrorText.equals(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath,"ErrorMessage", "ErrorMessageForLocation"))) {
				counter=++counter;
			}
			else if(actualErrorText.equals(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath,"ErrorMessage", "ErrorMessageForProcedures"))) {
				counter=++counter;
			}
			else if(actualErrorText.equals(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath,"ErrorMessage", "ErrorMessageForVisit"))) {
				counter=++counter ;
			}
		}
		assertEquals(counter, BfxUtlilities.getIntegerDataFromJsonArray(PackagePgTestDataPath, "ErrorMessage", "ErrorCount"));
	}
	
	
//	Verify the 0 " Quantity and Visits" Error message
	
	public void VerifytheNumbersErrorMsg() throws Exception {
		// Procedure
		Thread.sleep(3000);
		RandomString random=new RandomString();
		String randompackage=random.make(2);
		String pack=randompackage+BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "PackageName");
		packageName.sendKeys(pack);
		Thread.sleep(2000);
		BfxUtlilities.clickOnElementByActionClass(expiremonth);
		expiremonth.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "ExpireMonths"));
		percentagebtn.click();
		BfxUtlilities.clickOnElementByActionClass(packageDiscount);
		packageDiscount.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "PackageDiscount"));
		BfxUtlilities.scrollByJavaExecutor();
		BfxUtlilities.clickOnElementByActionClass(description);
		description.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "Description"));
		procedureBtn.click();
		BfxUtlilities.clickOnElementByActionClass(location);
		BfxUtlilities.selectTheOption(1);
		BfxUtlilities.clickOnElementByActionClass(procedureDropdown);
		BfxUtlilities.selectTheOption(3);
		BfxUtlilities.clickOnElementByActionClass(quantity);
		numberOfVisits.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "NumberOfVisitswith0"));
		BfxUtlilities.scrollUPByActionsClass();
		Thread.sleep(3000);
	}	
	
	
	public void VerifytheQuantityErrorMsg() throws Exception {
		Thread.sleep(3000);
		RandomString random=new RandomString();
		String randompackage=random.make(2);
		String pack=randompackage+BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "PackageName");
		packageName.sendKeys(pack);
		Thread.sleep(2000);
		BfxUtlilities.clickOnElementByActionClass(expiremonth);
		expiremonth.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "ExpireMonths"));
		percentagebtn.click();
		BfxUtlilities.clickOnElementByActionClass(packageDiscount);
		packageDiscount.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "PackageDiscount"));
		BfxUtlilities.scrollByJavaExecutor();
		BfxUtlilities.clickOnElementByActionClass(description);
		description.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "Description"));
		// Product
		productBtn.click();
		BfxUtlilities.clickOnElementByActionClass(location);
		BfxUtlilities.selectTheOption(1);
		BfxUtlilities.clickOnElementByActionClass(productLocation);
		BfxUtlilities.selectTheOption(1);
		BfxUtlilities.clickOnElementByActionClass(productsDropdown);
		BfxUtlilities.selectTheOption(4);
		BfxUtlilities.clickOnElementByActionClass(numberOfVisits);
		numberOfVisits.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AddPackage", "QuantityOfVisitswith0"));
		Thread.sleep(3000);
	}	
	
	
	
	
	public void validateNumberErrorMsg() throws Exception {	
		quantityErrorMsg.isDisplayed();
		String ActualError = quantityErrorMsg.getText();
		String ExpectedError = BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath,"AddPackage", "NumberOfVisitErrormsg");
		Assert.assertEquals(ExpectedError, ActualError);
		Thread.sleep(2000);	
	}
	
	public void validateQuantityErrorMsg() throws Exception {	
		quantityErrorMsg.isDisplayed();
		String ActualError = quantityErrorMsg.getText();
		String ExpectedError = BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath,"AddPackage", "QuantityOfVisitErrormsg");
		Assert.assertEquals(ExpectedError, ActualError);
		Thread.sleep(2000);	
	}
	
	public void validateDuplicatedRecordsFound() throws Exception {	
		duplicatedRecords.isDisplayed();
		String ActualError = duplicatedRecords.getText();
		String ExpectedError = BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath,"AddPackage", "DuplicatedRecordsFoundErrorMsg");
		Assert.assertEquals(ExpectedError, ActualError);
		Thread.sleep(2000);	
	}
	
	public void ValidatePackagePage() throws Exception {	
		packagePage.isDisplayed();
		String ActualError = packagePage.getText();
		String ExpectedError = BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath,"Search", "Packagepage");
		Assert.assertEquals(ExpectedError, ActualError);
		Thread.sleep(2000);	
	}
	
	public void searchPackageName() throws Exception {	
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(searchbtn);
		BfxUtlilities.clickOnElementByActionClass(searchInput);
		searchInput.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "Search", "Packagename"));
		Thread.sleep(2000);	
		findButton.click();
		searchPackageName.isDisplayed();
		String ActualError = searchPackageName.getText();
		String ExpectedError = BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath,"Search", "Expectedpackagename");
		Assert.assertEquals(ExpectedError, ActualError);
		Thread.sleep(2000);	
	}
	
	public void searchPackageNumber() throws Exception {	
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(searchbtn);
		Thread.sleep(2000);
		BfxUtlilities.clickOnElementByActionClass(searchSelect);
		BfxUtlilities.selectTheOption(1);
		BfxUtlilities.clickOnElementByActionClass(searchInput);
		searchInput.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "Search", "Packagenumber"));
		Thread.sleep(2000);	
		findButton.click();
		searchPackageNumber.isDisplayed();
		String ActualError = searchPackageNumber.getText();
		String ExpectedError = BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath,"Search", "ExpectedpackageNumber");
		Assert.assertEquals(ExpectedError, ActualError);
		Thread.sleep(2000);	
	}
	
	
	public void searchDeactivated() throws Exception {	
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(searchbtn);
		Thread.sleep(2000);
		BfxUtlilities.clickOnElementByActionClass(searchSelect);
		BfxUtlilities.selectTheOption(2);
		BfxUtlilities.clickOnElementByActionClass(deactivatedDropdown);
		BfxUtlilities.selectTheOption(2);
		Thread.sleep(2000);	
		findButton.click();
		Thread.sleep(3000);
		deactivatedSearch.isDisplayed();
		String ActualError = deactivatedSearch.getText();
		String ExpectedError = BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath,"Search", "DeactivatedSearchRecords");
		Assert.assertEquals(ExpectedError, ActualError);
		Thread.sleep(2000);	
	}
	
	
	public void searchTotalPrice() throws Exception {	
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(searchbtn);
		Thread.sleep(2000);
		BfxUtlilities.clickOnElementByActionClass(searchSelect);
		BfxUtlilities.selectTheOption(3);
		BfxUtlilities.clickOnElementByActionClass(searchInput);
		Thread.sleep(3000);	
		searchInput.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "Search", "total"));
		Thread.sleep(2000);	
		findButton.click();
		Thread.sleep(3000);
		totalPrice.isDisplayed();
		String ActualError = totalPrice.getText();
		String ExpectedError = BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath,"Search", "total");
		Assert.assertEquals(ExpectedError, ActualError);
		Thread.sleep(2000);	
	}
	
	
	public void searchDiscountedPrice() throws Exception {	
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(searchbtn);
		Thread.sleep(2000);
		BfxUtlilities.clickOnElementByActionClass(searchSelect);
		BfxUtlilities.selectTheOption(4);
		BfxUtlilities.clickOnElementByActionClass(searchInput);
		Thread.sleep(3000);	
		searchInput.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "Search", "DiscountedPrice"));
		Thread.sleep(2000);	
		findButton.click();
		Thread.sleep(3000);
		discountedPrice.isDisplayed();
		String ActualError = discountedPrice.getText();
		String ExpectedError = BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath,"Search", "DiscountedPrice");
		Assert.assertEquals(ExpectedError, ActualError);
		Thread.sleep(2000);	
	}
	
	
	public void searchStatus() throws Exception {	
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(searchbtn);
		Thread.sleep(2000);
		BfxUtlilities.clickOnElementByActionClass(searchSelect);
		BfxUtlilities.selectTheOption(5);
		BfxUtlilities.clickOnElementByActionClass(searchInput);
		Thread.sleep(3000);	
		searchInput.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "Search", "Statustype"));
		Thread.sleep(2000);	
		findButton.click();
		Thread.sleep(2000);	
		statustype.isDisplayed();
		String ActualError = statustype.getText();
		String ExpectedError = BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath,"Search", "Statustype");
		Assert.assertEquals(ExpectedError, ActualError);
		Thread.sleep(2000);	
	}
	
}
