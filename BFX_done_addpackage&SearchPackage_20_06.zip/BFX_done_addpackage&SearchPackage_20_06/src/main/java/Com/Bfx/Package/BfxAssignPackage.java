package Com.Bfx.Package;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.annotations.Test;

import Com.Bfx.BaseClass.BasePage;
import Com.Bfx.POM.patient.BfxAddPatient;
import Com.Bfx.Utilities.BfxUtlilities;

public class BfxAssignPackage extends BasePage{

	BfxAddPackage AddPackage=new BfxAddPackage();

	BasePage baseobj = new BasePage();
	JavascriptExecutor js = (JavascriptExecutor) baseobj.driver;

	public WebDriver driver;
	
	public BfxAssignPackage() {
		this.driver = baseobj.driver;
	}
	
	final String AssignPackages="//a[@href='/staging-pms/packages']//div[@role='button']";
	final String Utilities="/html/body/div[1]/div[1]/div/div[1]/div/div/div/div/ul[5]/li/div";
	final String AssignPackageAddBtn="//body[1]/div[1]/div[1]/div[1]/div[2]/div[1]/div[1]/div[1]/div[2]/div[4]/button[1]";
	final String PatientName = "//input[@id='patient']";
	final String PackageName="//input[@id='package']";
	final String Description = "//input[@id='description']";
	final String AssignPackagebtn="//button[@id='assignPackage']";	
	final String PackageAssignedErrorMsg="//div[contains(text(),'Package already assigned to the patient')]";
	
	@FindBy(xpath = PackageAssignedErrorMsg)
	public WebElement packageAssignedErrorMsg;

	@FindBy(xpath = AssignPackages)
	public WebElement assignPackage;

	@FindBy(xpath = AssignPackageAddBtn)
	public WebElement assignPackageAddBtn;
	
	@FindBy(xpath = Utilities)
	public WebElement utilities;
	
	@FindBy(xpath = PatientName)
	public WebElement patientName;
	
	@FindBy(xpath = PackageName)
	public WebElement packageName;	
	
	@FindBy(xpath = Description)
	public WebElement description;
	
	@FindBy(xpath = AssignPackagebtn)
	public WebElement assignPackagebtn;
	
	
	
	public void clickOnAssignPackage() throws Exception {
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(utilities);
		BfxUtlilities.clickOnElementByActionClass(assignPackage);
		BfxUtlilities.clickOnElementByActionClass(assignPackageAddBtn);
	}
	
	
	
	public void assignPackagetoSpecificPatient() throws Exception{
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(patientName);
		patientName.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage", "PatientName"));
		BfxUtlilities.clickOnElementByActionClass(patientName);
		BfxUtlilities.selectTheOption(1);
		Thread.sleep(3000);
		
		BfxUtlilities.clickOnElementByActionClass(packageName);
		packageName.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage", "PackageName"));
		BfxUtlilities.clickOnElementByActionClass(packageName);
		BfxUtlilities.selectTheOption(1);
		Thread.sleep(3000);	
		
		BfxUtlilities.clickOnElementByActionClass(description);
		description.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage", "Description"));
		BfxUtlilities.scrollByJavaExecutor();
		// assignPackagebtn.click();
	}
	
	
	public void assignedTheSamePackageToSamePatient() throws Exception{
		Thread.sleep(3000);
		BfxUtlilities.clickOnElementByActionClass(patientName);
		patientName.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage", "SamePatientName"));
		Thread.sleep(2000);
		BfxUtlilities.selectTheOption(1);
		
		BfxUtlilities.clickOnElementByActionClass(packageName);
		packageName.sendKeys(BfxUtlilities.getStringDataFromJsonArray(PackagePgTestDataPath, "AssignPackage", "SamePackageName"));
		Thread.sleep(2000);
		BfxUtlilities.selectTheOption(1);
		Thread.sleep(2000);	
		BfxUtlilities.scrollByJavaExecutor();
		 assignPackagebtn.click();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}
